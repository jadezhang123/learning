require('./browser')
require('./lang.modern')
require('./lang.share')
module.exports = require('./config')
