
var avalon = require('../dist/avalon.modern')
avalon.cache = require('./seed/cache')
require('../components/button/index')
require('../components/panel/index')

module.exports = avalon


