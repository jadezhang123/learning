var avalon = require("./seed/__test__")

require("./filters/__test__")
require("./vdom/__test__")
require("./dom/__test__")
require("./strategy/__test__")



  