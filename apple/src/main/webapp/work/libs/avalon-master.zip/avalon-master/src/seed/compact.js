
require('./lang.fix')
require('./browser')
require('./lang.compact')
require('./lang.share')
module.exports = require('./config')
