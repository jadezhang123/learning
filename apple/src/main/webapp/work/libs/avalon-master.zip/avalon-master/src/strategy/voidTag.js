module.exports = avalon.oneObject('area,base,basefont,bgsound,br,col,command,embed,' +
        'frame,hr,img,input,keygen,link,meta,param,source,track,wbr')